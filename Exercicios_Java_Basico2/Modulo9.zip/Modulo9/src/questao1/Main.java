package questao1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		Scanner s = new Scanner (System.in);      
        List<Integer> list = new ArrayList<Integer>();     
        
        for (int i = 0; i < 10; i++) {
        	
        	System.out.print("Digite um n�mero inteiro: ");
        	int resultado = s.nextInt();
        	list.add(resultado);
        }      
        
        Collections.sort(list);      
        System.out.println("N�meros Ordenados: " );      
        
        for (Integer i : list) {  
            System.out.println(i);  
        }  
        
        System.out.println("Tr�s menores valores: ");      
        
        for (int i = 0; i < 3; i++) {  
            System.out.println(list.get(i));  
        } 
        
        s.close();
    }
}
