package questao3;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class Main {

	public static void main(String[] args) {
		// Adicionar n�meros aleat�rios � lista:
		ArrayList<Integer> lista = new ArrayList<Integer>();
		Random r = new Random();

		for (int i = 0; i < 20; i++) {
			int novoNumero = r.nextInt();
			lista.add(novoNumero);
		}

		// Iterarar a lista e imprimir no console:
		Iterator<Integer> iterator = lista.iterator();

		while (iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}

}
