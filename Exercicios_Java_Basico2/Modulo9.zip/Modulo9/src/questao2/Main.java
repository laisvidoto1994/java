package questao2;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Main {

	public static void main(String[] args) {
		List<Aluno> listaAlunos = new ArrayList<Aluno>();
		listaAlunos.add(new Aluno("Carlos Ferraz", "Linux b�sico", 0));
		listaAlunos.add(new Aluno("Luis Fernando", "OpenOffice", 10));
		listaAlunos.add(new Aluno("Ant�nio Souza", "Internet", 7));
		listaAlunos.add(new Aluno("Paulo Roberto", "OpenOffice", 6));

		Collections.sort(listaAlunos);
		System.out.println(listaAlunos.toString());

	}

}
