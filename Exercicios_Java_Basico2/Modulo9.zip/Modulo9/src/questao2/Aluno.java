package questao2;

public class Aluno implements Comparable<Aluno> {
	
	private String nome;
	private String curso;
	private int nota;

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getCurso() {
		return curso;
	}

	public void setCurso(String curso) {
		this.curso = curso;
	}

	public int getNota() {
		return nota;
	}

	public void setNota(int nota) {
		this.nota = nota;
	}

	public Aluno(String nome, String curso, int nota) {
		this.nome = nome;
		this.curso = curso;
		this.nota = nota;
	}

	@Override
	public String toString() {
		return "Alunos - nome: " + nome + ", nota: " + nota + "\n";
	}

	@Override
	public int compareTo(Aluno alunos) {
		if (this.nota < alunos.nota) {
			return -1;
		}
		if (this.nota > alunos.nota) {
			return 1;
		}
		return 0;
	}
}